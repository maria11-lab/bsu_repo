#include "calculator.h"
#include "ui_calculator.h"
#include <cmath>

Calculator::Calculator(QWidget *parent)
    : QWidget(parent), ui(new Ui::Calculator) {
    ui->setupUi(this);

    ui->result->setReadOnly(true);

    // ИСПРАВЛЕНИЕ: Мы исключаем DEL из общего списка, чтобы она не писала "DEL" в поле
    QList<QPushButton*> buttons = this->findChildren<QPushButton*>();
    for(auto btn : buttons) {
        QString txt = btn->text();
        if (txt != "=" && txt != "AC" && txt != "DEL" && txt != "+/-" && txt != "%") {
            connect(btn, &QPushButton::clicked, this, &Calculator::on_button_clicked);
        }
    }
}

Calculator::~Calculator() { delete ui; }

void Calculator::on_button_clicked() {
    QPushButton *button = (QPushButton *)sender();
    ui->result->setText(ui->result->text() + button->text());
}

void Calculator::on_PushButton_AC_clicked() {
    ui->result->clear();
}

// ИСПРАВЛЕНИЕ DEL: Теперь она реально удаляет символ
void Calculator::on_pushButton_Del_clicked() {
    QString text = ui->result->text();
    if (!text.isEmpty()) {
        text.chop(1);
        ui->result->setText(text);
    }
}

void Calculator::on_pushButton_PM_clicked() {
    QString text = ui->result->text();
    if (text.isEmpty()) return;
    if (text.startsWith("-")) text.remove(0, 1);
    else text.prepend("-");
    ui->result->setText(text);
}

void Calculator::on_pushButton_Pr_clicked() {
    double val = ui->result->text().toDouble();
    ui->result->setText(QString::number(val / 100.0, 'g', 10));
}

void Calculator::on_pushButton_Equal_clicked() {
    RPNCalculator calc;
    QString exp = ui->result->text();
    if (exp.isEmpty()) return;

    try {
        double res = calc.calculate(exp);
        if (std::isinf(res) || std::isnan(res)) ui->result->setText("Error");
        else ui->result->setText(QString::number(res, 'g', 10));
    } catch (...) {
        ui->result->setText("Error");
    }
}

// --- ЛОГИКА ОПЗ ---

int RPNCalculator::getPriority(QString op) {
    if (op == "^") return 3;
    if (op == "*" || op == "/") return 2;
    if (op == "+" || op == "-") return 1;
    return 0;
}

QStringList RPNCalculator::tokenize(QString exp) {
    QStringList tokens;
    QString number;
    for (int i = 0; i < exp.length(); ++i) {
        QChar c = exp[i];
        if (c == '-' && (i == 0 || exp[i-1] == '(' || QString("+-*/^").contains(exp[i-1]))) {
            number += c;
            continue;
        }
        if (c.isDigit() || c == '.') {
            number += c;
        } else {
            if (!number.isEmpty()) { tokens << number; number.clear(); }
            if (!c.isSpace()) tokens << QString(c);
        }
    }
    if (!number.isEmpty()) tokens << number;
    return tokens;
}

double RPNCalculator::calculate(QString expression) {
    QStringList tokens = tokenize(expression);
    if (tokens.isEmpty()) return 0;

    QStack<double> values;
    QStack<QString> ops;

    auto applyOp = [&]() {
        // ИСПРАВЛЕНИЕ: Проверка размера стека перед pop(), чтобы не было краша
        if (values.size() < 2 || ops.isEmpty()) return;
        double r = values.pop();
        double l = values.pop();
        QString op = ops.pop();
        if (op == "+") values.push(l + r);
        else if (op == "-") values.push(l - r);
        else if (op == "*") values.push(l * r);
        else if (op == "/") {
            if (r == 0) values.push(qInf()); // Защита от деления на 0
            else values.push(l / r);
        }
        else if (op == "^") values.push(pow(l, r));
    };

    for (const QString& t : tokens) {
        bool ok;
        double val = t.toDouble(&ok);
        if (ok) {
            values.push(val);
        } else if (t == "(") {
            ops.push(t);
        } else if (t == ")") {
            while (!ops.isEmpty() && ops.top() != "(") applyOp();
            if (!ops.isEmpty()) ops.pop();
        } else {
            while (!ops.isEmpty() && getPriority(ops.top()) >= getPriority(t)) applyOp();
            ops.push(t);
        }
    }
    while (!ops.isEmpty()) applyOp();
    return values.isEmpty() ? 0 : values.top();
}